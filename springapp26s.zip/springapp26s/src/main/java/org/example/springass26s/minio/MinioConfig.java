package org.example.springass26s.Minio;

import io.minio.MinioClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MinioConfig {

    @Value("${minio.access.name}")
    private String accessKey;

    @Value("${minio.access.secret}")
    private String secretKey;

    @Value("${minio.url}")
    private String url;

    @Bean
    public MinioClient minoClientGeneration(){
        try {
            MinioClient minioClient =
                    MinioClient.builder()
                            .endpoint(url)
                            .credentials(accessKey, accessKey)
                            .build();
            return minioClient;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e.getMessage());
        }

    }


}
