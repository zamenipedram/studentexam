package org.example.springass26s.student;

import java.util.List;

public interface IStudentService {

    Student save(Student student);
    Student update(Student student);
    void delete(Long id);
    Student getById(Long id);
    List<Student> getAll();
}
