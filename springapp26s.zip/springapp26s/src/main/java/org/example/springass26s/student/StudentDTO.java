package org.example.springass26s.student;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@AllArgsConstructor
@Data
public class StudentDTO {

    @ApiModelProperty(required = true,hidden = false)
    @NotNull
    @NotBlank
    private final String wholeName;

    @ApiModelProperty(required = true,hidden = false)
    @NotNull
    @NotBlank
    private final String code;

}
