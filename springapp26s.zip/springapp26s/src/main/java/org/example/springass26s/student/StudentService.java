package org.example.springass26s.student;

import lombok.AllArgsConstructor;
import lombok.Data;
import org.example.springass26s.exception.NotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StudentService implements IStudentService {

    private StudentRepository repository;

    public StudentService(StudentRepository studentRepository) {
        this.repository = studentRepository;
    }

    @Override
    public Student save(Student student) {
        Student lastSavedStudent = getById(student.getId());
        lastSavedStudent.setNationalCode(student.getNationalCode());
        lastSavedStudent.setFullName(student.getFullName());
        lastSavedStudent.setAge(student.getAge());
        lastSavedStudent.setBirthday(student.getBirthday());

        repository.save(lastSavedStudent);

        return lastSavedStudent;
    }

    @Override
    public Student update(Student student) {
        Student newStudent = getById(student.getId());
        newStudent.setFullName(student.getFullName());
        newStudent.setNationalCode(student.getNationalCode());
        repository.save(newStudent);

        return newStudent;
    }

    @Override
    public void delete(Long id) {
        getById(id);
        repository.deleteById(id);
    }

    @Override
    public Student getById(Long id) {
        Optional<Student> optionalStudent = repository.findById(id);
        if (!optionalStudent.isPresent()) {
            throw new NotFoundException("not found");
        }
        return optionalStudent.get();
    }

    @Override
    public List<Student> getAll() {
        return (List<Student>) repository.findAll();
    }
}
