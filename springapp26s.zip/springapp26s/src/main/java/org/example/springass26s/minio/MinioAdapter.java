package org.example.springass26s.Minio;

import io.minio.GetObjectArgs;
import io.minio.MinioClient;
import io.minio.ObjectWriteResponse;
import io.minio.PutObjectArgs;
import io.minio.errors.*;
import io.minio.messages.Bucket;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.io.InputStream;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.List;

@Service
public class MinioAdapter {

    @Autowired
    MinioClient minioClient;


    @Value("${minio.buckek.name}")
    String defaultBucketName;
    @Value("${minio.default.folder}")
    String defaultBaseFolder;

    public List<Bucket> getALl(){
        try {
            return minioClient.listBuckets();
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e.getMessage());
        }
    }

    public String uploadFile(MultipartFile file) {

        try {
            String name=System.currentTimeMillis()+file.getOriginalFilename();
            ObjectWriteResponse objectWriteResponse=minioClient.putObject(
                    PutObjectArgs.builder().bucket(defaultBucketName).object(name)
                            .stream(file.getInputStream(), file.getSize(), -1)
                            .contentType(file.getContentType())
                            .build());

            return objectWriteResponse.object();


        } catch (Exception e) {
            e.printStackTrace();
        }

        throw new RuntimeException("not record");

    }

    public byte[] getFile(String key){

        InputStream  inputStream= null;
        try {
            inputStream = minioClient.getObject(
                    GetObjectArgs.builder()
                            .bucket(defaultBucketName)
                            .object(key)
                            .build());
            byte[] content = IOUtils.toByteArray(inputStream);
            inputStream.close();
            return content;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e.getMessage());
        }
    }

    @PostConstruct
    public void init() {
    }



}
