package org.example.springass26s.exception;

public class AccessDenied extends RuntimeException{
    public AccessDenied(String message) {
        super(message);
    }
}
