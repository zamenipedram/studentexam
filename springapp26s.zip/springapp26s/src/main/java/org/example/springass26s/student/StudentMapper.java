package org.example.springass26s.student;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import java.util.List;

@Mapper(componentModel = "spring")
public interface StudentMapper {

    @Mappings({@Mapping(source = "wholeName", target = "firstname")})
    Student toStudent(StudentDTO studentDTO);

    @Mappings({@Mapping(source = "firstname",target = "wholeName")})
    StudentDTO toStudentDTO(Student student);

    List<Student> toStudents(List<StudentDTO> studentDTOS);

    List<StudentDTO> toStudentDTOS(List<Student> students);

}
