package org.example.springass26s.student;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Table(name = "tbl_student")
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Student {

    @Id
    @Column(name = "id",unique = true,nullable = true)
    private Long id;

    @Column(name = "fullname",unique = true,nullable = true)
    private String fullName;

    @Column(name = "nationalcode",unique = true,nullable = true)
    private String nationalCode;

    @Column(name = "age",unique = true,nullable = true)
    private Integer age;

    @Column(name = "birthday",unique = true,nullable = true)
    private String birthday;

    @Transient
    private String fatherName;

    @Transient
    private String birthCity;





}
